<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname= "parkeasy";
$conn=mysqli_connect($servername,$username,$password,$dbname);
?>